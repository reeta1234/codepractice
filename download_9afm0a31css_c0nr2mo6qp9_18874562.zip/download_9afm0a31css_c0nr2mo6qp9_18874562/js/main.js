acctData = [
    {
        "acctNum": "A1234",
        "user": "Alice",
        "openDate": "4/5/89"
    },
    {
        "acctNum": "A5231",
        "user": "Bob",
        "openDate": "4/5/11"
    },
    {
        "acctNum": "A9921",
        "user": "Alice",
        "openDate": "4/5/19"
    },
    {
        "acctNum": "A8191",
        "user": "Alice",
        "openDate": "4/5/19"
    }
];

balance = {
	"A1234": 4593.22,
	"A9921": 0,
	"A5231": 232142.5,
	"A8191": 4344
};

var result = acctData.map(acct=>{
    return Object.assign({balance:balance[acct['acctNum']]},acct)
})

function getSortResult(user){
  return function(key,order = 'asc'){
  	result.sort(function (a, b) {
      if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {
        return 0;
      }

      const varA = (typeof a[key] === 'string')
      ? a[key].toUpperCase() : a[key];
      const varB = (typeof b[key] === 'string')
      ? b[key].toUpperCase() : b[key];

      let comparison = 0;
      if (varA > varB) {
        comparison = 1;
      } else if (varA < varB) {
        comparison = -1;
      }
      return (
        (order === 'desc') ? (comparison * -1) : comparison
      ); 
   
		});    
  	return result.filter(res=> (res.user.toLowerCase()==user.toLowerCase())?res:false)
  }
}

console.log(getSortResult('alice')('acctNum','asc'))